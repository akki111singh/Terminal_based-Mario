SUPER MARIO GAME:

CONTROLS:

w: jump upwards
a: move left
d: move right
q: to quit the game

KILL the enemy by jumping on their heads
Colorama is used for colouring & os.system('aplay filename.wav) for the sound

FEATURES:
This game contain:

1) springs
2) coins
3) powerup 
4) moving enemies
5) boss enemy ( kill the boss enemy by hitting the head of the boss enemy three times)
6) special bricks(on the hitting of which coin is released
7  at the end of the game when the flag comes down a spring appers through which the mario can clear the level

The game should be completed in the req time

